import mu_module as mm
print(mm.c, "- число пи")
print(mm.a, "- гравитационная постоянная")
print(mm.b, "- скорость света")
print(mm.d, "- ускорение свободного падения")
print(mm.e, "- Постоянная Планка")
