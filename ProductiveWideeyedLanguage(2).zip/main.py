import lec_3
import lec_3_2