import mu_module as mm
import numpy
import math
h = 100
alpha = mm.c / 3
beta = 30
g = mm.d
print((g*h*numpy.tan(beta**2)/2*numpy.cos(alpha**2)/2*numpy.cos(alpha**2)*(1-numpy.tan(beta)*numpy.tan(alpha)))**0.5)
T = 300
print((2/(math.pi)**0.5)*(mm.p/(mm.k*T)**3/2)*mm.eiler**-mm.eiler/mm.k*T
